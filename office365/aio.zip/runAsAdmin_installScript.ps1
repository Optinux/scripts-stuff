Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\setup.exe /download install365config.xml
.\setup.exe /configure install365config.xml